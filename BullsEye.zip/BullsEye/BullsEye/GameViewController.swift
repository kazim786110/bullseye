//
//  GameViewController.swift
//  BullsEye
//
//  Created by Syed Muhammad Kazim.
//

import UIKit

class GameViewController: UIViewController {
    
    @IBOutlet weak var inputNumberLabel: UILabel! //if the input number is not in range it show a text
    
    @IBOutlet weak var inputNumber: UITextField!   //the field where user enters the number input
    @IBOutlet weak var checkButton: UIButton! // Check button in the view cotroller
    
    @IBOutlet weak var generatedNumberOnLabel: UILabel! // Number that is generated on the screen after pressing the check button
    var numberOnLabel = Int.random(in: 1...100) // a value is generated using the function random and then this variable is associated with generatedNumberOnLabel
    
    var enteredNumber = "" // this variable is created to get the value of the text field after which its integer value is compared with the random value generated prior to this
    
    
// connection of bottom text that would be based on some conditions
    @IBOutlet weak var bottomMessageText: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
// button action when the button is pressed it would do some the application would do some tasks and check things after which the result would be generated
    
    @IBAction func didTapButtonInside(_ sender: Any) {
        bottomMessageText.text = ""
        numberOnLabel = Int.random(in: 1...100)
        enteredNumber = inputNumber.text ?? ""
        generatedNumberOnLabel.text = ""
        //code to check whether the user has entered the number within the range or not.
        if (1...100).contains(Int(enteredNumber) ?? 1000) {
            generatedNumberOnLabel.text = String(numberOnLabel)
            // check whether the entered value matches with the generated value
            inputNumberLabel.text = ""
            if Int(enteredNumber) == numberOnLabel {
                bottomMessageText.text =
"""
Congratulations! You've hit a bull's eye ;)
"""
            
            }
            else {
                bottomMessageText.text = " Try Again!"
            }
                
                
                
            
        }
        else {
            inputNumberLabel.text = "please enter a number in the specified range"
        }
    }
}

            
        
    
    
    


